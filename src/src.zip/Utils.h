#ifndef CC_UTILS_H
#define CC_UTILS_H
#include "String.h"
/* Implements various utility functions.
   Copyright 2014-2017 ClassicalSharp | Licensed under BSD-3
*/

/* Represents a particular instance in time in some timezone. Not necessarily UTC time. */
typedef struct DateTime_ {
	uint16_t Year;  /* Year,   ranges from 0 to 65535 */
	uint8_t Month;  /* Month,  ranges from 1 to 12 */
	uint8_t Day;    /* Day,    ranges from 1 to 31 */
	uint8_t Hour;   /* Hour,   ranges from 0 to 23 */
	uint8_t Minute; /* Minute, ranges from 0 to 59 */
	uint8_t Second; /* Second, ranges from 0 to 59 */
	uint16_t Milli; /* Milliseconds, ranges from 0 to 999 */
} DateTime;

#define DATETIME_MILLIS_PER_SEC 1000
int DateTime_TotalDays(const DateTime* time);
TimeMS DateTime_TotalMs(const DateTime* time);
void DateTime_FromTotalMs(DateTime* time, TimeMS ms);
void DateTime_HttpDate(TimeMS ms, String* str);

NOINLINE_ int Utils_ParseEnum(const String* text, int defValue, const char** names, int namesCount);
bool Utils_IsValidInputChar(char c, bool supportsCP437);
bool Utils_IsUrlPrefix(const String* value, int index);

/* Creates the directory if it doesn't exist. (logs failure in chat) */
bool Utils_EnsureDirectory(const char* dirName);
/* Gets the filename portion of a path. (e.g. "dir/file.txt" -> "file.txt") */
void Utils_UNSAFE_GetFilename(STRING_REF String* path);
int Utils_AccumulateWheelDelta(float* accumulator, float delta);
#define Utils_AdjViewDist(value) ((int)(1.4142135f * (value)))

uint8_t Utils_GetSkinType(const Bitmap* bmp);
uint32_t Utils_CRC32(const uint8_t* data, uint32_t length);
extern uint32_t Utils_Crc32Table[256];
NOINLINE_ void* Utils_Resize(void* buffer, uint32_t* maxElems, uint32_t elemSize, uint32_t defElems, uint32_t expandElems);
NOINLINE_ bool Utils_ParseIP(const String* ip, uint8_t* data);
#endif
