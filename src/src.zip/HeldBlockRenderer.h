#ifndef CC_HELDBLOCKRENDERER_H
#define CC_HELDBLOCKRENDERER_H
#include "Core.h"
/* Implements rendering of held block/arm at bottom right of game.
   Copyright 2014-2017 ClassicalSharp | Licensed under BSD-3
*/
struct IGameComponent;

void HeldBlockRenderer_ClickAnim(bool digging);
void HeldBlockRenderer_Render(double delta);
void HeldBlockRenderer_MakeComponent(struct IGameComponent* comp);
#endif
