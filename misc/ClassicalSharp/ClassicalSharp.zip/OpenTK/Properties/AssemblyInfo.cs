﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("OpenTK")]
[assembly: AssemblyDescription("Open source game development toolkit for .Net/Mono.")]
[assembly: AssemblyCompany("The Open Toolkit Library")]
[assembly: AssemblyProduct("The Open Toolkit Library")]
[assembly: AssemblyCopyright("Copyright © 2006 - 2010 the Open Toolkit Library")]
[assembly: AssemblyTrademark("OpenTK")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.99.9.4")]