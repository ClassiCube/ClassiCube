﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ClassicalSharp Client")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ClassicalSharp Client")]
[assembly: AssemblyCopyright("Copyright 2014 - 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.99.9.99")]
